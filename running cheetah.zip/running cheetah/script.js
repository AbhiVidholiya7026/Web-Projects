const pacman = document.getElementById('pacman');
const obstaclesContainer = document.getElementById('obstacles');
const applesContainer = document.getElementById('apples');
const scoreDisplay = document.getElementById('score');
const highScoreDisplay = document.getElementById('high-score');
const startBtn = document.getElementById('start-btn');
const pauseBtn = document.getElementById('pause-btn');
const retryBtn = document.getElementById('retry-btn');
const jumpSound = document.getElementById('jump-sound');
const appleSound = document.getElementById('apple-sound');
const gameArea = document.querySelector('.game-area');
const starsContainer = document.getElementById('stars');
const moon = document.getElementById('moon');
const sun = document.getElementById('sun');

let score = 0;
let highScore = localStorage.getItem('highScore') || 0;
let gameInterval;
let isPaused = false;
let isJumping = false;
let jumpCount = 0;
let backgroundInterval;

highScoreDisplay.textContent = highScore;

// Generate stars for night mode
function createStars() {
  for (let i = 0; i < 100; i++) {
    const star = document.createElement('div');
    star.classList.add('star');
    star.style.top = `${Math.random() * 100}%`;
    star.style.left = `${Math.random() * 100}%`;
    starsContainer.appendChild(star);
  }
}

createStars();

// Pac-Man jump
document.addEventListener('keydown', (e) => {
  if (e.code === 'Space') {
    if (!isJumping) {
      jump();
      jumpSound.play();
    } else if (jumpCount === 1) {
      doubleJump();
      jumpSound.play();
    }
  }
});

function jump() {
  if (isPaused) return;
  isJumping = true;
  let jumpHeight = 0;
  const jumpInterval = setInterval(() => {
    if (jumpHeight >= 80) {
      clearInterval(jumpInterval);
      const fallInterval = setInterval(() => {
        if (jumpHeight <= 0) {
          clearInterval(fallInterval);
          isJumping = false;
          jumpCount = 0;
        } else {
          jumpHeight -= 5;
          pacman.style.bottom = `${30 + jumpHeight}px`;
        }
      }, 20);
    } else {
      jumpHeight += 5;
      pacman.style.bottom = `${30 + jumpHeight}px`;
    }
  }, 20);
  jumpCount++;
}

function doubleJump() {
  let jumpHeight = 80;
  const doubleJumpInterval = setInterval(() => {
    if (jumpHeight >= 160) {
      clearInterval(doubleJumpInterval);
      const fallInterval = setInterval(() => {
        if (jumpHeight <= 0) {
          clearInterval(fallInterval);
          isJumping = false;
          jumpCount = 0;
        } else {
          jumpHeight -= 5;
          pacman.style.bottom = `${30 + jumpHeight}px`;
        }
      }, 20);
    } else {
      jumpHeight += 5;
      pacman.style.bottom = `${30 + jumpHeight}px`;
    }
  }, 20);
}

// Generate obstacles (cacti)
function createObstacle() {
  if (isPaused) return;
  const obstacle = document.createElement('div');
  obstacle.classList.add('obstacle');
  obstacle.style.right = '-100px';
  obstaclesContainer.appendChild(obstacle);

  // Move obstacle
  const obstacleInterval = setInterval(() => {
    if (isPaused) return;
    const obstacleRight = parseInt(obstacle.style.right);
    obstacle.style.right = `${obstacleRight + 5}px`;

    // Remove obstacle when it goes off-screen
    if (obstacleRight > 800) {
      clearInterval(obstacleInterval);
      obstacle.remove();
    }

    // Check for collision
    const pacmanRect = pacman.getBoundingClientRect();
    const obstacleRect = obstacle.getBoundingClientRect();

    if (
      pacmanRect.left < obstacleRect.right &&
      pacmanRect.right > obstacleRect.left &&
      pacmanRect.bottom > obstacleRect.top
    ) {
      clearInterval(gameInterval);
      clearInterval(backgroundInterval);
      alert(`Game Over! Your score: ${score}`);
      if (score > highScore) {
        highScore = score;
        localStorage.setItem('highScore', highScore);
        highScoreDisplay.textContent = highScore;
      }
    }
  }, 20);
}

// Generate apples
function createApple() {
  if (isPaused) return;
  const apple = document.createElement('div');
  apple.classList.add('apple');
  apple.style.right = '-100px';
  apple.style.bottom = `${Math.random() > 0.5 ? '90px' : '180px'}`; // Random height
  applesContainer.appendChild(apple);

  // Move apple
  const appleInterval = setInterval(() => {
    if (isPaused) return;
    const appleRight = parseInt(apple.style.right);
    apple.style.right = `${appleRight + 5}px`;

    // Remove apple when it goes off-screen
    if (appleRight > 800) {
      clearInterval(appleInterval);
      apple.remove();
    }

    // Check for collision
    const pacmanRect = pacman.getBoundingClientRect();
    const appleRect = apple.getBoundingClientRect();

    if (
      pacmanRect.left < appleRect.right &&
      pacmanRect.right > appleRect.left &&
      pacmanRect.bottom > appleRect.top
    ) {
      apple.remove();
      score *= 2; // Double the score
      scoreDisplay.textContent = score;
      appleSound.play();
    }
  }, 20);
}

// Start game
startBtn.addEventListener('click', () => {
  if (gameInterval) clearInterval(gameInterval);
  gameInterval = setInterval(() => {
    createObstacle();
    if (Math.random() < 0.1) createApple(); // 10% chance to spawn an apple
  }, 1000);
  isPaused = false;

  // Dynamic background changes
  const backgrounds = ['default', 'night-mode'];
  let index = 0;
  backgroundInterval = setInterval(() => {
    gameArea.classList.remove(...backgrounds);
    gameArea.classList.add(backgrounds[index]);
    index = (index + 1) % backgrounds.length;
  }, 15000); // Change background every 15 seconds
});

// Pause game
pauseBtn.addEventListener('click', () => {
  isPaused = !isPaused;
  if (isPaused) {
    clearInterval(gameInterval);
    clearInterval(backgroundInterval);
  } else {
    gameInterval = setInterval(() => {
      createObstacle();
      if (Math.random() < 0.1) createApple();
    }, 1000);
    backgroundInterval = setInterval(() => {
      gameArea.classList.remove(...backgrounds);
      gameArea.classList.add(backgrounds[index]);
      index = (index + 1) % backgrounds.length;
    }, 15000);
  }
});

// Retry game
retryBtn.addEventListener('click', () => {
  location.reload();
});